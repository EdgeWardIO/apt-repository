# 🪟 Multi-Site Sequential POC - Windows Package

## 📦 **What's Included**
- `multisite-sequential-poc.jar` - Main application
- `etcd.exe` - Windows etcd binary (22MB)
- `START-WINDOWS.bat` - Windows startup script
- `TESTING-GUIDE.md` - Complete testing instructions
- `WINDOWS-FIX.md` - Troubleshooting guide
- `MultiSite-Sequential-POC.postman_collection.json` - Postman tests

## 🚀 **Quick Start**

### **Step 1: Extract Package**
Extract all files to a folder (e.g., `C:\SequencePOC\`)

### **Step 2: Run the Application**
**Option A**: Double-click `START-WINDOWS.bat`

**Option B**: Command prompt:
```cmd
cd C:\SequencePOC
START-WINDOWS.bat
```

**Option C**: Manual start:
```cmd
set PATH=%PATH%;%CD%
java -jar multisite-sequential-poc.jar
```

### **Step 3: Wait for Startup**
- Application takes 30-60 seconds to start
- Watch for: `🎉 Multi-Site Sequential Number POC Started Successfully!`
- Dashboard available at: http://localhost:8080

## 📊 **Testing**

### **Web Dashboard**
Open in browser: http://localhost:8080
- Interactive testing interface
- Real-time monitoring
- Built-in test scenarios

### **Command Line Testing**
```cmd
# Basic sequence generation
curl -X POST http://localhost:8081/api/generate-invoices -H "Content-Type: application/json" -d "{\"partitionId\":\"CORP-A\",\"count\":5,\"invoiceType\":\"periodic\",\"customerType\":\"STANDARD\"}"

# Check system status  
curl http://localhost:8080/api/dashboard/status
```

### **Postman Testing**
Import `MultiSite-Sequential-POC.postman_collection.json` for comprehensive API testing.

## 🔧 **Requirements**
- **Windows 10/11** 
- **Java 17+** installed and in PATH
- **2GB RAM** available
- **Ports 8080-8084** available

## ✅ **Success Indicators**
- All services start without errors
- Dashboard loads at http://localhost:8080
- Sequence generation returns unique numbers
- Cross-site coordination works properly

## 🛠️ **Troubleshooting**
See `WINDOWS-FIX.md` for detailed troubleshooting steps.

---

**🎯 Ready for Windows Demo!** This package works completely offline on air-gapped Windows machines.