# 🧪 Multi-Site Sequential POC - Complete Testing Guide

## 🚀 How to Run the Application

### **Step 1: Download the Package**
```bash
curl -L -O https://github.com/EdgeWardIO/apt-repository/raw/main/multisite-sequential-poc-1.0.0-distribution.zip
unzip multisite-sequential-poc-1.0.0-distribution.zip
cd multisite-sequential-poc
```

### **Step 2: Ensure Prerequisites**
- **Java 17+** installed
- **Ports 8080-8084** available
- **2GB RAM** free
- **etcd binary** (included in package or system)

### **Step 3: Start the Application**

#### **Windows**
```cmd
java -jar multisite-sequential-poc.jar
```

#### **Linux/Mac**
```bash
java -jar multisite-sequential-poc.jar
```

### **Step 4: Wait for Startup**
- Application takes 30-60 seconds to fully start
- Watch for message: `🎉 Multi-Site Sequential Number POC Started Successfully!`
- Dashboard will be available at http://localhost:8080

## 📊 Service Endpoints

### **Main Services**
- **Web Dashboard**: http://localhost:8080
- **Site-A Formatter**: http://localhost:8081
- **Site-B Formatter**: http://localhost:8082
- **Site-A Sequence Service**: http://localhost:8083
- **Site-B Sequence Service**: http://localhost:8084

## 🎯 Testing Scenarios

### **1. Basic Sequence Generation - Site A**
```bash
curl -X POST http://localhost:8081/api/generate-invoices \
  -H "Content-Type: application/json" \
  -d '{
    "partitionId": "CORP-A",
    "count": 5,
    "invoiceType": "periodic",
    "customerType": "STANDARD"
  }'
```

### **2. Basic Sequence Generation - Site B**
```bash
curl -X POST http://localhost:8082/api/generate-invoices \
  -H "Content-Type: application/json" \
  -d '{
    "partitionId": "CORP-C",
    "count": 5,
    "invoiceType": "periodic",
    "customerType": "STANDARD"
  }'
```

### **3. Suppressed Invoice (Creates Gaps) - Site A**
```bash
curl -X POST http://localhost:8081/api/generate-invoices \
  -H "Content-Type: application/json" \
  -d '{
    "partitionId": "CORP-A",
    "count": 3,
    "invoiceType": "suppressed",
    "customerType": "STANDARD"
  }'
```

### **4. Gap Filling Test - Site B**
```bash
# First create gaps with suppressed invoices from Site-A
curl -X POST http://localhost:8081/api/generate-invoices \
  -H "Content-Type: application/json" \
  -d '{
    "partitionId": "CORP-A",
    "count": 3,
    "invoiceType": "suppressed",
    "customerType": "STANDARD"
  }'

# Then generate regular invoices from Site-B (should fill gaps)
curl -X POST http://localhost:8082/api/generate-invoices \
  -H "Content-Type: application/json" \
  -d '{
    "partitionId": "CORP-C",
    "count": 3,
    "invoiceType": "periodic",
    "customerType": "STANDARD"
  }'
```

### **5. On-Demand Invoice Generation**
```bash
curl -X POST http://localhost:8081/api/generate-invoices \
  -H "Content-Type: application/json" \
  -d '{
    "partitionId": "SMB-1",
    "count": 2,
    "invoiceType": "onDemand",
    "customerType": "PREMIUM"
  }'
```

### **6. Simulation Invoice (Separate Counter)**
```bash
curl -X POST http://localhost:8082/api/generate-invoices \
  -H "Content-Type: application/json" \
  -d '{
    "partitionId": "SMB-2",
    "count": 3,
    "invoiceType": "simulation",
    "customerType": "TEST"
  }'
```

### **7. Cross-Site Concurrent Test (Dashboard API)**
```bash
curl -X POST http://localhost:8080/api/dashboard/test/cross-site \
  -H "Content-Type: application/json" \
  -d '{
    "siteAPartition": "CORP-A",
    "siteACount": 5,
    "siteBPartition": "CORP-C",
    "siteBCount": 5,
    "invoiceType": "periodic"
  }'
```

### **8. Check System Status**
```bash
# Dashboard status
curl http://localhost:8080/api/dashboard/status

# Site-A Formatter status
curl http://localhost:8081/api/status

# Site-B Formatter status
curl http://localhost:8082/api/status

# Get global counters
curl http://localhost:8080/api/dashboard/counters
```

### **9. Health Checks**
```bash
# Site-A health
curl http://localhost:8081/actuator/health

# Site-B health
curl http://localhost:8082/actuator/health

# Sequence service stats
curl http://localhost:8083/api/v1/sequence/stats
curl http://localhost:8084/api/v1/sequence/stats
```

### **10. Direct Sequence Service Calls**
```bash
# Site-A direct sequence generation
curl "http://localhost:8083/api/v1/sequence/next?siteId=US-EAST&partitionId=CORP-A&invoiceType=periodic&count=3"

# Site-B direct sequence generation
curl "http://localhost:8084/api/v1/sequence/next?siteId=US-WEST&partitionId=CORP-C&invoiceType=periodic&count=3"
```

## 🔍 Expected Test Results

### **Successful Invoice Generation**
```json
{
  "success": true,
  "message": "Generated 5 invoices successfully",
  "invoices": [
    {
      "sequenceNumber": 1045,
      "formattedNumber": "RE-000001045-1",
      "siteId": "SITE-A",
      "partitionId": "CORP-A",
      "invoiceType": "periodic",
      "amount": 1234.56,
      "generatedAt": "2025-08-10T15:30:00",
      "gapFilled": false
    }
  ]
}
```

### **Gap Filled Invoice**
```json
{
  "sequenceNumber": 1029,
  "formattedNumber": "RE-000001029-1",
  "gapFilled": true  // Note: This was a previously suppressed sequence
}
```

### **System Status Response**
```json
{
  "siteA": {
    "formatter": "UP",
    "sequence": "UP"
  },
  "siteB": {
    "formatter": "UP",
    "sequence": "UP"
  }
}
```

## 🎭 Test Scenarios to Validate

### **Scenario 1: Global Counter Consistency**
1. Generate 5 sequences from Site-A (e.g., 1001-1005)
2. Generate 5 sequences from Site-B (should be 1006-1010)
3. Verify no duplicates and continuous sequence

### **Scenario 2: Cross-Site Gap Filling**
1. Create 3 suppressed invoices from Site-A (creates gaps)
2. Generate periodic invoices from Site-B
3. Verify Site-B reuses the gaps created by Site-A

### **Scenario 3: Concurrent Generation**
1. Send simultaneous requests to both sites
2. Verify no duplicate sequences
3. Check global counter progression

### **Scenario 4: Different Invoice Types**
1. Test periodic invoices (RE- prefix)
2. Test on-demand invoices (OD_ prefix)
3. Test simulation invoices (separate counter)
4. Verify formatting strategies applied correctly

### **Scenario 5: Multiple Partitions**
1. Site-A: Test CORP-A, CORP-B, SMB-1
2. Site-B: Test CORP-C, CORP-D, SMB-2
3. Verify partition numbers in formatted sequences

## 🛠️ Troubleshooting

### **Services Not Starting**
- Check if all ports (8080-8084) are available
- Ensure Java 17+ is installed
- Wait full 60 seconds for startup
- Check console logs for specific errors

### **etcd Connection Issues**
- Verify etcd processes are running
- Check ports 2379, 2389, 2399
- Look for "etcd cluster started successfully" in logs

### **Dashboard Not Loading**
- Clear browser cache
- Try incognito/private mode
- Check JavaScript console for errors
- Ensure http://localhost:8080 (not https)

## 📝 Testing Checklist

- [ ] Application starts successfully
- [ ] Dashboard loads at http://localhost:8080
- [ ] Site-A generates sequences correctly
- [ ] Site-B generates sequences correctly
- [ ] Global counter increments properly
- [ ] No duplicate sequences across sites
- [ ] Gap filling works between sites
- [ ] Suppressed invoices create gaps
- [ ] Different invoice types format correctly
- [ ] All partitions work as expected
- [ ] Concurrent requests handled correctly
- [ ] Health checks return UP status
- [ ] System survives load testing

---

**💡 TIP**: Use the Web Dashboard at http://localhost:8080 for visual testing - it has buttons for all test scenarios!