#!/bin/bash

# Multi-Site Sequential Number POC - Unix/Linux/Mac Startup Script
# ================================================================

echo
echo "  ========================================================================"
echo "  🚀 Multi-Site Sequential Number Generation POC"
echo "  ========================================================================"
echo
echo "  Starting distributed invoice number generation system..."
echo "  This will launch:"
echo "  - 3-node embedded etcd cluster"
echo "  - Site-A Formatter + Sequence Service (ports 8081, 8083)"
echo "  - Site-B Formatter + Sequence Service (ports 8082, 8084)"
echo "  - Web Dashboard (port 8080)"
echo
echo "  ⚠️  Requirements: Java 17 or higher"
echo "  💡 Dashboard URL: http://localhost:8080"
echo
echo "  ========================================================================"
echo

# Check Java version
if ! command -v java &> /dev/null; then
    echo "❌ ERROR: Java is not installed or not in PATH"
    echo
    echo "Please install Java 17 or higher and ensure it's in your PATH"
    echo "Download from: https://adoptium.net/"
    exit 1
fi

# Check Java version is 17+
JAVA_VERSION=$(java -version 2>&1 | head -1 | cut -d'"' -f2 | sed '/^1\./s///' | cut -d'.' -f1)
if [ "$JAVA_VERSION" -lt 17 ]; then
    echo "❌ ERROR: Java 17 or higher is required (found Java $JAVA_VERSION)"
    echo
    echo "Please upgrade your Java version"
    echo "Download from: https://adoptium.net/"
    exit 1
fi

# Check if ports are available
echo "🔍 Checking port availability..."
if lsof -i:8080 >/dev/null 2>&1; then
    echo "⚠️  WARNING: Port 8080 is already in use"
    echo "Some services may fail to start"
    echo
fi

# Set JVM options for better performance
JAVA_OPTS="-Xmx2G -Xms1G -XX:+UseG1GC -XX:MaxGCPauseMillis=200"

# Make script executable
chmod +x "$0"

# Start the application
echo "🚀 Starting Multi-Site POC..."
echo
echo "⏳ This may take 30-60 seconds to fully initialize all services..."
echo

# Trap Ctrl+C for graceful shutdown
trap 'echo; echo "🛑 Gracefully shutting down Multi-Site POC..."; kill $APP_PID 2>/dev/null; wait $APP_PID 2>/dev/null; echo "✅ Shutdown complete"; exit 0' INT TERM

# Start in background to handle signals
java $JAVA_OPTS -jar multisite-sequential-poc.jar &
APP_PID=$!

# Wait for the application
wait $APP_PID

echo
echo "🛑 Multi-Site POC has stopped"