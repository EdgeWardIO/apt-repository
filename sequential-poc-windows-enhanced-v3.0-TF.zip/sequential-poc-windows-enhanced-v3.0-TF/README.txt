Sequential Number POC - Windows Deployment (Complete Demo - v2.0)
================================================================

This is the complete Windows deployment package with comprehensive use cases 
and proper localhost configuration for seamless demonstration.

REQUIREMENTS:
- Java 17 or later
- Windows 10 or later

TO START:
1. Double-click start-poc.bat
2. Wait for the application to start
3. Open http://localhost:5000/dashboard in your browser

TO STOP:
- Press Ctrl+C in the command window

POSTMAN TESTING:
1. Import Sequential-POC-Windows.postman_collection.json into Postman
2. Run the comprehensive "Gapless Invoice Use Cases - Complete Demo" collection
3. The collection includes 6 complete use cases demonstrating:
   - On-cycle gapless invoicing
   - Multi-site coordination
   - On-demand different strategies
   - Gap management and recovery
   - System monitoring
   - Load testing

CONFIGURATION:
- Server runs on localhost:5000 (not port 8080)
- Uses external etcd server on localhost:2379
- Includes real invoice-config.json with multi-site setup
- etcd data stored in etcd-data directory

FIXED ISSUES (v2.0):
✅ Changed server port from 8080 to 5000 for proper Postman testing
✅ Updated all URLs to use localhost instead of physical IP addresses
✅ Enhanced Postman collection with comprehensive use cases matching "Gapless Invoice Use Cases - Complete Demo"
✅ Added actual invoice-config.json from DEMO directory
✅ Improved startup script with correct port configuration
✅ Added multi-site configuration (US-EAST, US-WEST, EU-WEST, APAC, LATAM)

TROUBLESHOOTING:
- If port 5000 is busy, stop other applications using that port
- If etcd fails to start, check if port 2379 is available
- Check Java version with: java -version
- Dashboard: http://localhost:5000/dashboard
- API Base: http://localhost:5000/api/v1
